class Compo2():
    def __init__(self):
        self.name = "Compo2"

    def testFunc(self):
        return "testFunc"

class Compo1_2():
    def __init__(self):
        self.name = "Compo2_2"

    def testFunc(self):
        return "testFunc"