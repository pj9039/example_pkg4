class Compo1():
    def __init__(self):
        self.name = "Compo1"

    def testFunc(self):
        return "testFunc"

class Compo1_1():
    def __init__(self):
        self.name = "Compo1_1"

    def testFunc(self):
        return "testFunc"