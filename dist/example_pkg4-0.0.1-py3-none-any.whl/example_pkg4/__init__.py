class TestClass(object):
    def __init__(self):
        self.name       = "init"

    def testFunc(self):
        return "testFunc"

    def testFunc2(self):
        return "testFunc2"


class TestClass2(object):
    def __init__(self):
        self.name = "init"

    def testFunc(self):
        return "testFunc"

    def testFunc2(self):
        return "testFunc2"

